
package Config;

public interface Parametros {
    String url = "jdbc:mysql://localhost:3309/rh";
    String Driver = "com.mysql.jdbc.Driver";
    String user = "root";
    String clave = "78465076";    
}
